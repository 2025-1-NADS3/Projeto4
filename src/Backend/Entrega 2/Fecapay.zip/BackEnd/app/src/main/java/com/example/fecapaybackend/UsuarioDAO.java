package com.example.fecapaybackend;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UsuarioDAO {

    private DBHelper dbHelper;

    public UsuarioDAO(Context context) {
        dbHelper = new DBHelper(context);
    }

    // ------------------- CREATE (Cadastrar novo usuário com criptografia) -------------------
    public boolean cadastrarUsuario(String nome, String sobrenome, String ra, String celular,
                                    String cpf, String email, String senha) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Criptografar senha e CPF
        String senhaCriptografada = CriptoUtils.criptografar(senha);
        String cpfCriptografado = CriptoUtils.criptografar(cpf);

        ContentValues valores = new ContentValues();
        valores.put(DBHelper.COL_NOME, nome);
        valores.put(DBHelper.COL_SOBRENOME, sobrenome);
        valores.put(DBHelper.COL_RA, ra);
        valores.put(DBHelper.COL_CELULAR, celular);
        valores.put(DBHelper.COL_CPF, cpfCriptografado); // CPF criptografado
        valores.put(DBHelper.COL_EMAIL, email);
        valores.put(DBHelper.COL_SENHA, senhaCriptografada); // Senha criptografada

        long resultado = db.insert(DBHelper.TABLE_USUARIOS, null, valores);
        db.close();

        return resultado != -1;
    }

    // ------------------- READ (Verificar login com senha criptografada) -------------------
    public boolean verificarLogin(String email, String senha) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String senhaCriptografada = CriptoUtils.criptografar(senha);

        String query = "SELECT * FROM " + DBHelper.TABLE_USUARIOS +
                " WHERE " + DBHelper.COL_EMAIL + " = ?" +
                " AND " + DBHelper.COL_SENHA + " = ?";

        String[] args = { email, senhaCriptografada };

        Cursor cursor = db.rawQuery(query, args);
        boolean existe = cursor.moveToFirst();
        cursor.close();
        return existe;
    }

    // ------------------- UPDATE (Atualizar senha criptografada) -------------------
    public boolean atualizarSenha(String email, String novaSenha) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String novaSenhaCriptografada = CriptoUtils.criptografar(novaSenha);

        ContentValues valores = new ContentValues();
        valores.put(DBHelper.COL_SENHA, novaSenhaCriptografada);

        int linhasAfetadas = db.update(DBHelper.TABLE_USUARIOS, valores,
                DBHelper.COL_EMAIL + " = ?", new String[]{email});

        return linhasAfetadas > 0;
    }

    // ------------------- DELETE (Excluir conta com senha criptografada) -------------------
    public boolean excluirUsuario(String email, String senha) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String senhaCriptografada = CriptoUtils.criptografar(senha);

        int linhasAfetadas = db.delete(DBHelper.TABLE_USUARIOS,
                DBHelper.COL_EMAIL + " = ? AND " + DBHelper.COL_SENHA + " = ?",
                new String[]{email, senhaCriptografada});

        return linhasAfetadas > 0;
    }
}
